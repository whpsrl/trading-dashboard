import ChartAnalyzer from '@/components/ChartAnalyzer';

export default function Home() {
  return <ChartAnalyzer />;
}
